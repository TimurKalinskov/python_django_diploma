# from django.urls import path
#
# from . import views
#
# urlpatterns = [
#     path('addtocart/', views.AddtocartView.as_view({'get': 'list'}), name='addtocart'),
#     path('cart/', views.CartView.as_view({'get': 'list'}), name='cart'),
# ]
