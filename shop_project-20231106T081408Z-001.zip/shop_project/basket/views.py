# from django.shortcuts import render, get_object_or_404, redirect
# from rest_framework import viewsets
#
# # Create your views here.
# from .serializers import AddtocartSerializers, CartSerializers
# from .models import OrderItem, Order
#
#
# class AddtocartView(viewsets.ModelViewSet):
#     authentication_classes = []
#     permission_classes = []
#     pagination_class = None
#     queryset = OrderItem
#     serializer_class = AddtocartSerializers
#
#
# class CartView(viewsets.ModelViewSet):
#     authentication_classes = []
#     permission_classes = []
#     pagination_class = None
#     queryset = Order.objects.all()
#     serializer_class = CartSerializers