# from django.contrib.auth.models import User
# from rest_framework import serializers
#
# from frontend.models import Item, Review
#
#
#
# class ItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Item
#         fields = ['name', 'image', 'description', 'price']
#
#
# class ReviewSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Review
#         fields = '__all__'
from rest_framework import serializers

from basket.models import Basket
from catalog.models import Banner, Tag


# class AddtocartSerializers(serializers.ModelSerializer):
#     class Meta:
#         model = OrderItem
#         fields = ['image_number', 'title', 'image_size', 'file_type', 'price']
#
#
# class CartSerializers(serializers.ModelSerializer):
#     class Meta:
#         model = Order
#         fields = ['item',
#                   'start_date',
#                   'ordered_date'
#                   ]
#

class BasketBaseSerializer(serializers.ModelSerializer):
    count = serializers.SerializerMethodField()

    class Meta:
        model = Basket
        fields = '__all__'

    def get_count(self, obj):
        return '5'


class BasketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Basket
        fields = ('item', 'count')

    def create(self, validated_data):
        user = self.context.get('request').user
        basket = Basket.objects.create(user=user, **validated_data)
        return basket


class BannersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Banner
        field = ('filler',)


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        field = ('name',)
