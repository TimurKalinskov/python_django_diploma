# from rest_framework.generics import CreateAPIView, ListAPIView, RetrieveAPIView
#
# from .models import Item, Review
# from .serializers import ItemSerializer, ReviewSerializer
#
#
# class CatalogView(ListAPIView):
#     model = Item
#     serializer_class = ItemSerializer
#
#
# class ReviewRetrieveAPIView(RetrieveAPIView):
#     queryset = Review.objects.all()
#     serializer_class = ReviewSerializer
#     lookup_field = 'id'
#
#
# class AddToCartAPIView(CreateAPIView):
#     queryset = Item.objects.all()
#     serializer_class = ItemSerializer
#     lookup_field = 'id'
#
#     def create(self, request, *args, **kwargs):
#         response = super().create(request, *args, **kwargs)
#         message = {
#             'message': 'Product added to cart successfully',
#             'cart_url': 'your_cart_url'
#         }
#         return response(message)
from django.shortcuts import render, get_object_or_404, redirect
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from catalog.models import Banner, Tag
# # Create your views here.
from .serializers import BasketSerializer, BasketBaseSerializer, BannersSerializer, TagSerializer
from basket.models import Basket


#
#
# class AddtocartView(viewsets.ModelViewSet):
#     authentication_classes = []
#     permission_classes = []
#     pagination_class = None
#     queryset = OrderItem
#     serializer_class = AddtocartSerializers
#
#
# class CartView(viewsets.ModelViewSet):
#     authentication_classes = []
#     permission_classes = []
#     pagination_class = None
#     queryset = Order.objects.all()
#     serializer_class = CartSerializers


class BasketModelView(viewsets.ModelViewSet):
    queryset = Basket.objects.all()

    # permission_classes = [IsAuthenticated]
    def get_serializer_class(self):
        if self.action in ['create']:
            return BasketSerializer
        return BasketBaseSerializer


class BannerModelView(viewsets.ModelViewSet):
    queryset = Banner.objects.all()
    serializer_class = BannersSerializer


class TagModelView(viewsets.ModelViewSet):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer