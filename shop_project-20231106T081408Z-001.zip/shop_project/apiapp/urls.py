from django.urls import path, include
from rest_framework.routers import DefaultRouter

from apiapp.views import BasketModelView, BannerModelView
from userapp.views import LoginView, register, logout

from apiapp.views import TagModelView

router = DefaultRouter()
router.register('basket', BasketModelView)
router.register('banners', BannerModelView)
router.register('tags', TagModelView)
urlpatterns = [
    path('', include(router.urls)),
    path('sign-in', LoginView.as_view()),
    path('sign-out', logout)
]
